package com.example.bookstore.service_discovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceDiscoveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
