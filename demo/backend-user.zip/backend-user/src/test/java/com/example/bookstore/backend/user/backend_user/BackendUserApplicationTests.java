package com.example.bookstore.backend.user.backend_user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
